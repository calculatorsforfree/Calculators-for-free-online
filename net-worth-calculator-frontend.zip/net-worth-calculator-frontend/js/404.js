document.getElementById("back-to-homepage").addEventListener("click", e => location.href = "index.html");
document.getElementById("name-plate").textContent = "";