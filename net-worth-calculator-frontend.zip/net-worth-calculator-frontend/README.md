# Muses Net Worth Calculator

## Overview

A Net Worth Calculator web app using HTML, SCSS and JS (ES6)
Hosted here: https://net-worth-calculator.netlify.com/


- Run `npm install` to install dependencies(in this case, node-sass)
- Run `npm run compile-sass` to compile the sass files or `npm run watch-sass` to watch

